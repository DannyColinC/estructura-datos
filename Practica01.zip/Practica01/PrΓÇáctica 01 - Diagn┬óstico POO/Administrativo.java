public interface Administrativo {

	double BONO_MAXIMO = 10000;
	
	String administrar();
	String definirAumentos();
	String reportarLogros();	
}